﻿using UnityEngine;
using System.Collections;

public enum GPUSkinningShaderType
{
	Unlit, 
	StandardSpecular, 
	StandardMetallic
}
