﻿using UnityEngine;
using System.Collections;

public enum GPUSkinningQuality
{
	Bone1,
	Bone2, 
	Bone4
}
